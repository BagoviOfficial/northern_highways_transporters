from django.db import models
from django.utils.text import slugify


class Route(models.Model):
    name = models.CharField(max_length=100, unique=True, db_index=True, help_text="Destination town or stop (e.g. Mandera, Garissa)")
    slug = models.SlugField(max_length=120, unique=True, db_index=True)
    origin = models.CharField(max_length=100, default='Nairobi', help_text="Origin terminal (defaults to Nairobi HQ)")
    description = models.TextField(blank=True, help_text="Transit notes or stopover details")
    is_active = models.BooleanField(default=True, db_index=True, help_text="Inactive routes cannot be selected for new parcels")
    created_at = models.DateTimeField(auto_now_add=True)
    updated_at = models.DateTimeField(auto_now=True)

    class Meta:
        ordering = ['name']
        verbose_name = 'Route'
        verbose_name_plural = 'Routes'

    def __str__(self):
        return f"{self.origin} -> {self.name}"

    def save(self, *args, **kwargs):
        if not self.slug:
            base_slug = slugify(self.name)
            slug = base_slug
            counter = 1
            while Route.objects.filter(slug=slug).exclude(pk=self.pk).exists():
                slug = f"{base_slug}-{counter}"
                counter += 1
            self.slug = slug
        super().save(*args, **kwargs)

    def can_be_deleted(self):
        """Check if any parcels reference this route."""
        return not self.parcels.exists()
