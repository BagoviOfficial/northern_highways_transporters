#!/bin/bash

# Define Variables (Fixed URL to standard github.com path format)
REPO_URL="https://github.com"
DEFAULT_BRANCH="main"
PROJECT_DIR="parcel_system"
BACKUP_FILE="database_schema.sql"

echo "🔐 Starting automated Git push for Private Django project..."

# 1. Parse Database Type and Name directly from settings.py or .env
if [ -f ".env" ] && grep -q "USE_SQLITE=True" .env; then
    IS_SQLITE=true
elif grep -q "USE_SQLITE=(bool, True)" "$PROJECT_DIR/settings.py" && ! grep -q "USE_SQLITE" .env 2>/dev/null; then
    IS_SQLITE=true
else
    IS_SQLITE=false
fi

# 2. Database Backup Logic
if [ "$IS_SQLITE" = true ]; then
    echo "ℹ️  Project is currently set to use offline SQLite fallback."
else
    DB_NAME=$(grep "DB_NAME" .env 2>/dev/null | cut -d'=' -f2 | tr -d "'\" ")
    if [ -z "$DB_NAME" ]; then
        DB_NAME=$(grep "DB_NAME=" "$PROJECT_DIR/settings.py" | grep -o "'[^']*'" | head -n 1 | tr -d "'")
    fi
    [ -z "$DB_NAME" ] && DB_NAME="parcel_db"

    # Verify if PostgreSQL is up before attempting dump to prevent script crashes
    if pg_isready >/dev/null 2>&1; then
        read -p "🗄️  Export PostgreSQL schema for '$DB_NAME'? (y/N): " export_db
        if [[ "$export_db" =~ ^[Yy]$ ]]; then
            echo "💾 Dumping PostgreSQL structure..."
            pg_dump -d "$DB_NAME" --schema-only > "$BACKUP_FILE"
            echo "✅ Schema saved to $BACKUP_FILE"
        fi
    else
        echo "⚠️  PostgreSQL server is not active (pg_isready failed). Skipping database backup step..."
    fi
fi

# 3. Initialize Git if not already tracking
if [ ! -d ".git" ]; then
    echo "📦 Initializing local Git repository..."
    git init
    
    if [ ! -f ".gitignore" ]; then
        cat << 'EOF' > .gitignore
*.pyc
__pycache__/
db.sqlite3
.env
*.env
local_settings.py
staticfiles/
media/
EOF
        echo "📝 Generated standard .gitignore file."
    fi
fi

# 4. Sync remote origin configuration explicitly
if git remote | grep -q "origin"; then
    echo "🔗 Updating remote origin to the correct URL..."
    git remote set-url origin "$REPO_URL"
else
    echo "🔗 Setting remote origin..."
    git remote add origin "$REPO_URL"
fi

# 5. Set default branch to main
git branch -M "$DEFAULT_BRANCH"

# 6. Prompt for commit message
read -p "📝 Enter commit message [Default: 'Update Northern Highways System']: " commit_msg
if [ -z "$commit_msg" ]; then
    commit_msg="Update Northern Highways System"
fi

# 7. Stage and Commit changes
echo "➕ Staging files..."
git add .

echo "💾 Committing changes..."
git commit -m "$commit_msg"

# 8. Push to private repository (Git will explicitly prompt for user credentials here)
echo "📤 Pushing code to secure private repository ($DEFAULT_BRANCH)..."
echo "💡 (Note: When prompted, provide your GitHub username and use your PAT as the password)"
git push -u origin "$DEFAULT_BRANCH"

if [ $? -eq 0 ]; then
    echo "🎉 Success! Code safely updated on GitHub."
else
    echo "❌ Push failed. Please check your credentials or network connection."
fi

