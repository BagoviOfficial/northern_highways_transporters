from django.db.models import QuerySet
from accounts.models import Role
from .models import Parcel


def get_parcels_for_user(user, queryset: QuerySet = None) -> QuerySet:
    """
    Returns parcels visible to the user based on RBAC and object-level route restrictions.
    Super Admin, Operations Manager, and Read Only see all parcels.
    Counter staff see all parcels (can search and book).
    Dispatch staff see all operational parcels.
    Destination staff see ONLY parcels destined for their assigned route!
    """
    if queryset is None:
        queryset = Parcel.objects.select_related('route', 'created_by').prefetch_related('items')

    if not user.is_authenticated:
        return queryset.none()

    if user.is_superuser or user.role in [Role.SUPER_ADMIN, Role.OPERATIONS_MANAGER, Role.READ_ONLY, Role.COUNTER_STAFF, Role.DISPATCH_STAFF]:
        return queryset

    if user.role == Role.DESTINATION_STAFF:
        if user.assigned_route:
            return queryset.filter(route=user.assigned_route)
        return queryset.none()

    return queryset.none()


def can_user_access_parcel(user, parcel: Parcel) -> bool:
    """
    Validates if user can view/access a specific parcel instance.
    Prevents IDOR/BOLA attacks.
    """
    if not user.is_authenticated or not user.is_active:
        return False

    if user.is_superuser or user.role in [Role.SUPER_ADMIN, Role.OPERATIONS_MANAGER, Role.READ_ONLY, Role.COUNTER_STAFF, Role.DISPATCH_STAFF]:
        return True

    if user.role == Role.DESTINATION_STAFF:
        return user.assigned_route_id is not None and parcel.route_id == user.assigned_route_id

    return False
