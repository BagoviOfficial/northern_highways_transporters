from django.core.cache import cache
from .models import SiteSettings, FieldConfig, ChoiceConfig


def get_site_settings():
    """Retrieve cached site settings singleton."""
    return SiteSettings.load()


def get_field_configs():
    """Retrieve all active field configurations mapped by field_key."""
    configs = cache.get('field_configs_cache')
    if configs is None:
        qs = FieldConfig.objects.filter(is_active=True).order_by('order')
        configs = {cfg.field_key: cfg for cfg in qs}
        cache.set('field_configs_cache', configs, timeout=3600)
    return configs


def get_active_choices(category):
    """Retrieve active choices for a specific category as (key, label) tuples."""
    cache_key = f'choice_configs_{category}'
    choices = cache.get(cache_key)
    if choices is None:
        qs = ChoiceConfig.objects.filter(category=category, is_active=True).order_by('order', 'label')
        choices = [(c.key, c.label) for c in qs]
        cache.set(cache_key, choices, timeout=3600)
    return choices


def apply_dynamic_field_configs(form):
    """
    Applies configured labels, placeholders, help_text, and required rules
    to form fields dynamically. Never executes arbitrary code.
    """
    configs = get_field_configs()
    for field_name, field in form.fields.items():
        if field_name in configs:
            cfg = configs[field_name]
            if cfg.label:
                field.label = cfg.label
            if cfg.placeholder:
                field.widget.attrs['placeholder'] = cfg.placeholder
            if cfg.help_text:
                field.help_text = cfg.help_text
            field.required = cfg.is_required
            if not cfg.is_visible:
                field.widget.attrs['style'] = 'display:none;'
